package cn.itcast.netty.c5;

public class HelloWorldClient {
}
