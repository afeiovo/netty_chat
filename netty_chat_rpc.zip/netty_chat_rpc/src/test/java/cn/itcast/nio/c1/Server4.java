package cn.itcast.nio.c1;

import cn.itcast.nio.c2.ByteBufferUtil;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

@Slf4j
public class Server4 {
    public static void main(String[] args) throws IOException {
        //1. 创建selector，管理多个channel，建立channel
        Selector selector = Selector.open();
        ServerSocketChannel ssc = ServerSocketChannel.open();
        ssc.configureBlocking(false);//必须设置成非阻塞。

        //2. 建立 selector 和 channel 的联系（注册）
        SelectionKey sscKey = ssc.register(selector , 0 , null);
        sscKey.interestOps(SelectionKey.OP_ACCEPT);

        log.debug("redister key:{}" , sscKey);

        ssc.bind(new InetSocketAddress(8080));

        while (true) {
            //3. 没有事件时，线程阻塞，有事件发声时，线程恢复运行。
            // select 如果事件未处理，他不会阻塞，事件发生后要么处理，要么取消，不能置之不理。
            selector.select();

            //4. 处理事件，selectedKeys() 内部包含所有事件。
            Iterator<SelectionKey> iter = selector.selectedKeys().iterator();

            while(iter.hasNext()){//sc的read事件也会在这个集合中。
                SelectionKey key = iter.next();
                //处理key时，要把它从集合中删除，否则下次还会遍历这个key。
                iter.remove();
                log.debug("key : {}" , key);

                //处理事件
                if(key.isAcceptable()) {
                    ServerSocketChannel channel = (ServerSocketChannel) key.channel();
                    SocketChannel sc = channel.accept();
                    log.debug("{}", sc);

                    sc.configureBlocking(false);
                    ByteBuffer buffer = ByteBuffer.allocate(16);
                    SelectionKey scKey = sc.register(selector, 0, buffer);
                    scKey.interestOps(SelectionKey.OP_READ);
                }else if(key.isReadable()){
                    try {
                        SocketChannel channel = (SocketChannel) key.channel();

                        ByteBuffer buffer = (ByteBuffer) key.attachment();
                        int read = channel.read(buffer); //如果是正常断开引发的read，返回值是-1。
                        if(read == -1){
                            key.cancel();
                        }else {
                            split(buffer);
                            if(buffer.position() == buffer.limit()){
                                ByteBuffer newBuffer = ByteBuffer.allocate(2*buffer.capacity());
                                buffer.flip();
                                newBuffer.put(buffer);
                                key.attach(newBuffer);
                            }
//                            debugRead(buffer);
                            buffer.clear();
                        }
                    } catch (IOException e) {//客户端正常断开和强制断开都会触发read事件，此时channel.read()发生IO异常。
                        e.printStackTrace();
                        key.cancel();
                    }
                }
                //5. 取消事件。
//                key.cancel();
            }
        }
    }
    private static void split(ByteBuffer buffer) {

        buffer.flip();

        for(int i = 0; i < buffer.limit(); i++) {
            if (buffer.get(i) == '\n') {
                int length = i+1-buffer.position();
                ByteBuffer target = ByteBuffer.allocate(length);

                for(int j = 0; j < length; j++) {
                    target.put(buffer.get());
                }

                ByteBufferUtil.debugAll(target);
            }
        }

        buffer.compact();
    }
}
