package cn.itcast.nio.c1;

import cn.itcast.nio.c2.ByteBufferUtil;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;

@Slf4j
public class UdpServer {
    public static void main(String[] args) {

        try (DatagramChannel channel = DatagramChannel.open()) {
            channel.socket().bind(new InetSocketAddress(9999));

            System.out.println("waiting...");

            ByteBuffer buffer = ByteBuffer.allocate(32);
            channel.receive(buffer);

            buffer.flip();
            ByteBufferUtil.debugAll(buffer);
        } catch ( IOException e) {
            e.printStackTrace();
        }
    }
}
