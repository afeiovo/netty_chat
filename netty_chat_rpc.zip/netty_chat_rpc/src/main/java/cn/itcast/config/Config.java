package cn.itcast.config;

public class Config {

}
