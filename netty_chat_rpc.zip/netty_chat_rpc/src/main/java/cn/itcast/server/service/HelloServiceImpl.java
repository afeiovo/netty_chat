package cn.itcast.server.service;

public class HelloServiceImpl implements HelloService {
    public String sayHello(String s) {
        int i = 1 / 0;
        return "hello-->" + s;
    }
}
